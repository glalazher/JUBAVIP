let score = 10; // قيمة النقاط الابتدائية

function login() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    // يمكنك هنا إضافة التحقق من اسم المستخدم وكلمة المرور
    // إذا كانت صحيحة، قم بعرض واجهة اللعبة وإخفاء واجهة تسجيل الدخول
    if (isValidLogin(username, password)) {
        document.getElementById("login-container").style.display = "none";
        document.getElementById("game-container").style.display = "block";
    } else {
        alert("اسم المستخدم أو كلمة المرور غير صحيحة!");
    }
}

function chooseCard(cardNumber) {
    if (score <= 0) {
        alert("لقد انتهت اللعبة! النقاط الإجمالية: " + score);
        return;
    }

    const correctCard = Math.floor(Math.random() * 3) + 1;

    if (cardNumber === correctCard) {
        alert("اختيار صحيح! تمت إضافة نقطة واحدة.");
        score += 1;
    } else {
        alert("اختيار خاطئ. تم خصم نقطة واحدة.");
        score -= 1;
    }

    updateScore();
}

function updateScore() {
    document.getElementById("score").innerText = "النقاط: " + score;

    if (score <= 0) {
        alert("لقد انتهت اللعبة! النقاط الإجمالية: " + score);
    }
}

function isValidLogin(username, password) {
    // يمكنك هنا إضافة الشروط للتحقق من صحة اسم المستخدم وكلمة المرور
    // هذا مثال بسيط، يمكنك تحسينه بما يناسب متطلباتك
    return username === "JUBAVIP" && password === "JUBA VIP";
}
